#!/bin/sh

# ntp servers here
servers=(
	# domain cn.ntp.org.cn
	"118.24.4.66"		# ntp.org.cn
	"118.24.195.65"		# ntp.org.cn
	"118.24.236.43"		# ntp.org.cn
	"202.108.6.95"		# ntp.org.cn
	"120.25.108.11"		# aliyun
	"182.92.12.11"		# aliyun
	"203.107.6.88"		# aliyun
	"120.25.115.20"		# aliyun

	# domain edu.ntp.org.cn
	"202.112.31.197"	# Northeastern University
	"202.112.29.82"		# Northeastern University
	"202.118.1.130"		# Northeastern University
	"202.118.1.81"		# Northeastern University
)

# path for ntpdate
ntpdate=ntpdate

while true; do
	echo "update time started ..."
	succeed=0

	for server in ${servers[@]}; do
		echo "update time with server:" $server "..."
		$ntpdate $server
		if [ $? -eq 0 ]; then
			succeed=1
			break
		fi
	done

	if [ $succeed -ne 0 ]; then
		echo "update time succeeded."
		sleep 600	# ten minutes
	else
		echo "update time failed."
		sleep 10	# ten seconds
	fi
done


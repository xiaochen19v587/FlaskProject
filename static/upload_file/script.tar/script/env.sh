#!/bin/sh

export XDG_RUNTIME_DIR=/run/user/0
export TERM="xterm-256color"
export LD_LIBRARY_PATH=/data/zros/lib
export MAIN_UI_ENTRANCE=1
export ZROS_CONSOLE_LOG_LEVEL=1
